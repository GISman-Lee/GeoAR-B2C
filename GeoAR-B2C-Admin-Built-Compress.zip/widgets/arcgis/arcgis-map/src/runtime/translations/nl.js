define({
  _widgetLabel: 'Kaart',
  _action_displayFeatureSet_label: 'Featureset weergeven',
  _action_panTo_label: 'Pannen naar',
  _action_zoomToFeature_label: 'Zoomen naar',
  _action_selectFeature_label: 'Object selecteren',
  _action_flash_label: 'Flash',
  _action_filter_label: 'Filteren'
});