define({
  _widgetLabel: 'Mappa',
  _action_displayFeatureSet_label: 'Visualizzare set di feature',
  _action_panTo_label: 'Effettua Zoom A',
  _action_zoomToFeature_label: 'Zoom a',
  _action_selectFeature_label: 'Seleziona feature',
  _action_flash_label: 'Flash',
  _action_filter_label: 'Filtro'
});