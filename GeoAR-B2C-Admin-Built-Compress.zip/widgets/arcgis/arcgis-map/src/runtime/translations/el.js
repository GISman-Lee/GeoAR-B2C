define({
  _widgetLabel: 'Χάρτης',
  _action_displayFeatureSet_label: 'Εμφάνιση συνόλου στοιχείων',
  _action_panTo_label: 'Μετατόπιση',
  _action_zoomToFeature_label: 'Εστίαση σε',
  _action_selectFeature_label: 'Επιλογή στοιχείου',
  _action_flash_label: 'Flash',
  _action_filter_label: 'Φιλτράρισμα'
});