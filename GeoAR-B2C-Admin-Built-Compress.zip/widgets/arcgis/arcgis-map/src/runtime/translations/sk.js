define({
  _widgetLabel: 'Mapa',
  _action_displayFeatureSet_label: 'Zobraziť sadu prvkov',
  _action_panTo_label: 'Posun na',
  _action_zoomToFeature_label: 'Priblížiť na',
  _action_selectFeature_label: 'Vybrať prvok',
  _action_flash_label: 'Záblesk',
  _action_filter_label: 'Filter'
});