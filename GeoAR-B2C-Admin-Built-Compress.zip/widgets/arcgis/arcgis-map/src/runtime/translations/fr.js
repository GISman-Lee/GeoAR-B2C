define({
  _widgetLabel: 'Carte',
  _action_displayFeatureSet_label: 'Afficher le jeu d’entités',
  _action_panTo_label: 'Déplacer sur',
  _action_zoomToFeature_label: 'Zoom sur',
  _action_selectFeature_label: 'Sélectionner une entité',
  _action_flash_label: 'Faire clignoter',
  _action_filter_label: 'Filtrer'
});