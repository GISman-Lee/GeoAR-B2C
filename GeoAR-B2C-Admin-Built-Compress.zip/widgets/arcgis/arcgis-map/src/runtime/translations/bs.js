define({
  _widgetLabel: 'Karta',
  _action_displayFeatureSet_label: 'Prikaži skup geoobjekta',
  _action_panTo_label: 'Kreći se do',
  _action_zoomToFeature_label: 'Povećaj na',
  _action_selectFeature_label: 'Odaberite geoobjekt',
  _action_flash_label: 'Bljeskalica',
  _action_filter_label: 'Filtriraj'
});