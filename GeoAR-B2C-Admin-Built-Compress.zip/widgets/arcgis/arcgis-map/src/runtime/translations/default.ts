export default {
  _widgetLabel: 'Map',
  _action_displayFeatureSet_label: 'Display feature set',
  _action_panTo_label: 'Pan to',
  _action_zoomToFeature_label: 'Zoom to',
  _action_selectFeature_label: 'Select feature',
  _action_flash_label: 'Flash',
  _action_filter_label: 'Filter'
}
