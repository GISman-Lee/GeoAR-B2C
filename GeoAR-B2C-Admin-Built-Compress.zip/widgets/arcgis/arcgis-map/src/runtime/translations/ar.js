define({
  _widgetLabel: 'خريطة',
  _action_displayFeatureSet_label: 'عرض مجموعة المعالم',
  _action_panTo_label: 'تحريك إلى',
  _action_zoomToFeature_label: 'تكبير/تصغير إلى',
  _action_selectFeature_label: 'حدد المعلم',
  _action_flash_label: 'وميض',
  _action_filter_label: 'عامل تصفية'
});