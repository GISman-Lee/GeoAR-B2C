define({
  _widgetLabel: 'Harita',
  _action_displayFeatureSet_label: 'Detay kümesini görüntüle',
  _action_panTo_label: 'Kaydır',
  _action_zoomToFeature_label: 'Yakınlaştır',
  _action_selectFeature_label: 'Detay seç',
  _action_flash_label: 'Vurgula',
  _action_filter_label: 'Filtre Uygula'
});