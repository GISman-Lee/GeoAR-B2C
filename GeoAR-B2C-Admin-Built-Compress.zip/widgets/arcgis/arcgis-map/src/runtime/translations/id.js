define({
  _widgetLabel: 'Peta',
  _action_displayFeatureSet_label: 'Tampilkan rangkaian fitur',
  _action_panTo_label: 'Geser hingga',
  _action_zoomToFeature_label: 'Zoom hingga',
  _action_selectFeature_label: 'Pilih fitur',
  _action_flash_label: 'Flash',
  _action_filter_label: 'Filter'
});