define({
  _widgetLabel: 'Bản đồ',
  _action_displayFeatureSet_label: 'Hiển thị bộ đối tượng',
  _action_panTo_label: 'Di chuyển đến',
  _action_zoomToFeature_label: 'Phóng tới',
  _action_selectFeature_label: 'Chọn đối tượng',
  _action_flash_label: 'Đèn flash',
  _action_filter_label: 'Bộ lọc'
});