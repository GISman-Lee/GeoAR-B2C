define({
  _widgetLabel: 'Karta',
  _action_displayFeatureSet_label: 'Visa geoobjektset',
  _action_panTo_label: 'Panorera till',
  _action_zoomToFeature_label: 'Zooma till',
  _action_selectFeature_label: 'Välj geoobjekt',
  _action_flash_label: 'Blinka',
  _action_filter_label: 'Filter'
});