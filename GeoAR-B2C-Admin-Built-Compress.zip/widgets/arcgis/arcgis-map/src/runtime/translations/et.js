define({
  _widgetLabel: 'Kaart',
  _action_displayFeatureSet_label: 'Kuva objektikogum',
  _action_panTo_label: 'Liiguta',
  _action_zoomToFeature_label: 'Suumi',
  _action_selectFeature_label: 'Vali objekt',
  _action_flash_label: 'Välguta',
  _action_filter_label: 'Filtreeri'
});