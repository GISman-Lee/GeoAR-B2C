define({
  _widgetLabel: 'แผนที่',
  _action_displayFeatureSet_label: 'แสดงชุดฟีเจอร์',
  _action_panTo_label: 'เลื่อนไปที่',
  _action_zoomToFeature_label: 'ขยายไปยัง',
  _action_selectFeature_label: 'เลือกฟีเจอร์',
  _action_flash_label: 'แฟลช',
  _action_filter_label: 'ตัวกรอง'
});