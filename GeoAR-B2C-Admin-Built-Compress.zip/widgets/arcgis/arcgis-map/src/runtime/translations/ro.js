define({
  _widgetLabel: 'Hartă',
  _action_displayFeatureSet_label: 'Afișare set de obiecte spațiale',
  _action_panTo_label: 'Panoramare la',
  _action_zoomToFeature_label: 'Transfocare la',
  _action_selectFeature_label: 'Selectare obiect spațial',
  _action_flash_label: 'Flash',
  _action_filter_label: 'Filtru'
});