define({
  _widgetLabel: 'Image',
  imageChooseShape: 'Σχήμα',
  imageCrop: 'Περικοπή'
});