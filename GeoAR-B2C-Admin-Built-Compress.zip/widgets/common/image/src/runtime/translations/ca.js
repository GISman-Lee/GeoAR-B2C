define({
  _widgetLabel: 'Imatge',
  imageChooseShape: 'Forma',
  imageCrop: 'Retalla'
});