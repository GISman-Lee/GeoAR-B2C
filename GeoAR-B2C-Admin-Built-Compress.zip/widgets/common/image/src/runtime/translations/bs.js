define({
  _widgetLabel: 'Slika',
  imageChooseShape: 'Oblik',
  imageCrop: 'Obreži'
});