define({
  _widgetLabel: 'Atvaizdas',
  imageChooseShape: 'Forma',
  imageCrop: 'Apkarpyti'
});