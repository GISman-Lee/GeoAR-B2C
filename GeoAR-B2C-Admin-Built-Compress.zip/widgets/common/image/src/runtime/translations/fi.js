define({
  _widgetLabel: 'kuva',
  imageChooseShape: 'Muoto',
  imageCrop: 'Rajaa'
});