define({
  _widgetLabel: 'Imagen',
  imageChooseShape: 'Forma',
  imageCrop: 'Recortar'
});