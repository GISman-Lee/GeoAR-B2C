define({
  _widgetLabel: 'Immagine',
  imageChooseShape: 'Forma',
  imageCrop: 'Ritaglia'
});