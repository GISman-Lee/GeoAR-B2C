define({
  _widgetLabel: 'Imagem',
  imageChooseShape: 'Formato',
  imageCrop: 'Cortar'
});