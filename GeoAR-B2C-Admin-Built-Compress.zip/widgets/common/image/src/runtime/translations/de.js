define({
  _widgetLabel: 'Bild',
  imageChooseShape: 'Form',
  imageCrop: 'Zuschneiden'
});