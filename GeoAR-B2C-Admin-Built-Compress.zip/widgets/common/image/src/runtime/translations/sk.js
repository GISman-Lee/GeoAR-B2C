define({
  _widgetLabel: 'Obrázok',
  imageChooseShape: 'Tvar',
  imageCrop: 'Orezať'
});