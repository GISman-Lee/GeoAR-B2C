export default {
  _widgetLabel: 'Image',
  imageChooseShape: 'Shape',
  imageCrop: 'Crop'
}