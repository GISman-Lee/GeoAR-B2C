define({
  _widgetLabel: 'Bild',
  imageChooseShape: 'Objekt',
  imageCrop: 'Beskär'
});