define({
  _widgetLabel: 'Imagine',
  imageChooseShape: 'Formă',
  imageCrop: 'Decupare'
});