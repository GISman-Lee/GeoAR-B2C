define({
  _widgetLabel: '影像',
  imageChooseShape: '形状',
  imageCrop: '裁切'
});