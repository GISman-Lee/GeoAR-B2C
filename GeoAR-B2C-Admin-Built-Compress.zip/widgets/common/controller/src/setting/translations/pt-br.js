define({
  _widgetLabel: 'Controlador de Widget',
  behavior: 'Comportamento',
  openWidget: 'Quantos widgets podem ser abertos',
  displayType: 'Tipo de Exibição',
  sideBySide: 'Lado a lado',
  iconStyle: 'Ícone',
  showIconLabel: 'Rótulo',
  iconSizeOverride: 'Tamanho',
  iconInterval: 'Espaçamento',
  textFormatOverride: 'Texto',
  iconBackgroundOverride: 'Ícone',
  openStart: 'Abre os widgets quando a página for carregada',
  widgetsSelected: '{widgetNumber} widgets selecionados'
});