define({
  _widgetLabel: 'أداة التحكم في عنصر واجهة المستخدم',
  behavior: 'السلوك',
  openWidget: 'كم عدد عناصر واجهة المستخدم التي يمكن فتحها',
  displayType: 'نوع العرض',
  sideBySide: 'جنبًا إلى جنب',
  iconStyle: 'أيقونة',
  showIconLabel: 'التسمية',
  iconSizeOverride: 'الحجم',
  iconInterval: 'التباعد',
  textFormatOverride: 'النص',
  iconBackgroundOverride: 'أيقونة',
  openStart: 'فتح عناصر واجهة المستخدم عند تحميل الصفحة',
  widgetsSelected: 'تم تحديد {widgetNumber} من عناصر واجهة المستخدم'
});