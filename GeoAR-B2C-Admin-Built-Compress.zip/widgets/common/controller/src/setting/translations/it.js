define({
  _widgetLabel: 'Controllore del widget',
  behavior: 'Comportamento',
  openWidget: 'Quanti widget possono essere aperti',
  displayType: 'Tipo visualizzazione',
  sideBySide: 'Affiancato',
  iconStyle: 'Icona',
  showIconLabel: 'Etichetta',
  iconSizeOverride: 'Dimensione',
  iconInterval: 'Spaziatura',
  textFormatOverride: 'Testo',
  iconBackgroundOverride: 'Icona',
  openStart: 'Aprire i widget quando si è caricata la pagina',
  widgetsSelected: '{widgetNumber} widget selezionati'
});