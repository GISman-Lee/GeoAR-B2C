define({
  _widgetLabel: 'Контролер віджетів',
  behavior: 'Поведінка',
  openWidget: 'Скільки віджетів можна відкрити',
  displayType: 'Тип відображення',
  sideBySide: 'Пліч-о-пліч',
  iconStyle: 'Значок',
  showIconLabel: 'Напис',
  iconSizeOverride: 'Розмір',
  iconInterval: 'Пробіл',
  textFormatOverride: 'Текст',
  iconBackgroundOverride: 'Значок',
  openStart: 'Відкривати віджети при завантаженні сторінки',
  widgetsSelected: 'Вибрано {widgetNumber} віджетів'
});