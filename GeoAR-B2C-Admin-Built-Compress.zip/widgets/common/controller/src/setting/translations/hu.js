define({
  _widgetLabel: 'Widgetvezérlő',
  behavior: 'Viselkedés',
  openWidget: 'Hány widget nyitható meg?',
  displayType: 'Megjelenítő típusa',
  sideBySide: 'Egymás mellett',
  iconStyle: 'Ikon',
  showIconLabel: 'Felirat',
  iconSizeOverride: 'Méret',
  iconInterval: 'Térköz',
  textFormatOverride: 'Szöveg',
  iconBackgroundOverride: 'Ikon',
  openStart: 'Widgetek megnyitása, ha az oldal betöltődött',
  widgetsSelected: '{widgetNumber} widget kiválasztva'
});