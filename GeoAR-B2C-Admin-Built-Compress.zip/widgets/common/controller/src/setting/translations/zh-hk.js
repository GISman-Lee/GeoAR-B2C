define({
  _widgetLabel: 'Widget 控制器',
  behavior: '行為',
  openWidget: '可開啟的 widget 數量為何',
  displayType: '顯示類型',
  sideBySide: '並排',
  iconStyle: '圖示',
  showIconLabel: '標籤',
  iconSizeOverride: '大小',
  iconInterval: '間距',
  textFormatOverride: '文字',
  iconBackgroundOverride: '圖示',
  openStart: '載入頁面時開啟 widget',
  widgetsSelected: '已選擇 {widgetNumber} 個 widget'
});