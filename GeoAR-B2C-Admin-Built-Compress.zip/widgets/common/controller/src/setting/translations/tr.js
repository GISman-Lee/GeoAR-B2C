define({
  _widgetLabel: 'Widget Controller (Araç Denetleyicisi)',
  behavior: 'Davranış',
  openWidget: 'Kaç tane araç açılabilir',
  displayType: 'Görüntüleme türü',
  sideBySide: 'Yan yana',
  iconStyle: 'Simge',
  showIconLabel: 'Etiket',
  iconSizeOverride: 'Boyut',
  iconInterval: 'Boşluk',
  textFormatOverride: 'Metin',
  iconBackgroundOverride: 'Simge',
  openStart: 'Araçları sayfa yüklendiğinde aç',
  widgetsSelected: '{widgetNumber} araç seçildi'
});