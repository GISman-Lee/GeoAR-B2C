define({
  _widgetLabel: 'ウィジェット コントローラー',
  behavior: '動作',
  openWidget: '開くことのできるウィジェットの数',
  displayType: '表示タイプ',
  sideBySide: 'サイド バイ サイド',
  iconStyle: 'アイコン',
  showIconLabel: 'ラベル',
  iconSizeOverride: 'サイズ',
  iconInterval: '間隔',
  textFormatOverride: 'テキスト',
  iconBackgroundOverride: 'アイコン',
  openStart: 'ページを読み込むときにウィジェットを開く',
  widgetsSelected: '{widgetNumber} ウィジェットが選択されています'
});