define({
  _widgetLabel: 'Miniprogramkontroller',
  behavior: 'Atferd',
  openWidget: 'Hvor mange miniprogrammer kan åpnes',
  displayType: 'Vis type',
  sideBySide: 'Side ved side',
  iconStyle: 'Ikon',
  showIconLabel: 'Etikett',
  iconSizeOverride: 'Størrelse',
  iconInterval: 'Mellomrom',
  textFormatOverride: 'Tekst',
  iconBackgroundOverride: 'Ikon',
  openStart: 'Åpne miniprogrammer når siden er lastet',
  widgetsSelected: '{widgetNumber} miniprogrammer er valgt'
});