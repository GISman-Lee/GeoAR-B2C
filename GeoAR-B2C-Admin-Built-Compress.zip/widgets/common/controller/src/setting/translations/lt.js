define({
  _widgetLabel: 'Valdiklis',
  behavior: 'Veikimas',
  openWidget: 'Kiek valdiklių galima atidaryti',
  displayType: 'Rodymo būdas',
  sideBySide: 'Lygiagrečiai',
  iconStyle: 'Piktograma',
  showIconLabel: 'Žymė',
  iconSizeOverride: 'Dydis',
  iconInterval: 'Pakeisti tarpus',
  textFormatOverride: 'Tekstas',
  iconBackgroundOverride: 'Piktograma',
  openStart: 'Atidaryti valdiklius įkėlus puslapį',
  widgetsSelected: 'Pasirinkti {widgetNumber} valdikliai (-ių)'
});