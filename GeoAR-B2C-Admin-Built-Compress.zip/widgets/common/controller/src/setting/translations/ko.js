define({
  _widgetLabel: '위젯 컨트롤러',
  behavior: '동작',
  openWidget: '열 수 있는 위젯 개수',
  displayType: '표시 유형',
  sideBySide: '병렬',
  iconStyle: '아이콘',
  showIconLabel: '레이블',
  iconSizeOverride: '크기',
  iconInterval: '간격',
  textFormatOverride: '텍스트',
  iconBackgroundOverride: '아이콘',
  openStart: '페이지가 로드되면 위젯을 엽니다.',
  widgetsSelected: '{widgetNumber}개의 위젯이 선택됨'
});