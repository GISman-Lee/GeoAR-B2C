define({
  _widgetLabel: 'Pienoisohjelman säädin',
  behavior: 'Toiminta',
  openWidget: 'Avattavien pienoisohjelmien määrä',
  displayType: 'Näyttötyyppi',
  sideBySide: 'Rinnakkain',
  iconStyle: 'Kuvake',
  showIconLabel: 'Tunnusteksti',
  iconSizeOverride: 'Koko',
  iconInterval: 'Välistys',
  textFormatOverride: 'Teksti',
  iconBackgroundOverride: 'Kuvake',
  openStart: 'Avaa pienoisohjelmat, kun sivu ladataan',
  widgetsSelected: '{widgetNumber} pienoisohjelmaa valittu'
});