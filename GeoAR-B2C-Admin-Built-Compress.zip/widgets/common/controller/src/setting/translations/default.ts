export default {
  _widgetLabel: 'Widget Controller',
  behavior: 'Behavior',
  openWidget: 'How many widgets can be opened',
  displayType: 'Display type',
  sideBySide: 'Side by side',
  iconStyle: 'Icon',
  showIconLabel: 'Label',
  iconSizeOverride: 'Size',
  iconInterval: 'Spacing',
  textFormatOverride: 'Text',
  iconBackgroundOverride: 'Icon',
  openStart: 'Open widgets when the page is loaded',
  widgetsSelected: '{widgetNumber} widgets selected'
}
