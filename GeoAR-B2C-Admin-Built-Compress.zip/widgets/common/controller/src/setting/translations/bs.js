define({
  _widgetLabel: 'Kontoler widgeta',
  behavior: 'Ponašanje',
  openWidget: 'Koliko je widgeta moguće otvoriti?',
  displayType: 'Prikaži vrstu',
  sideBySide: 'Usporedo',
  iconStyle: 'Ikona',
  showIconLabel: 'Oznaka',
  iconSizeOverride: 'Veličina',
  iconInterval: 'Razmak',
  textFormatOverride: 'Tekst',
  iconBackgroundOverride: 'Ikona',
  openStart: 'Otvori widgete kada se stranica učita',
  widgetsSelected: 'Odabran je sljedeći broj widgeta: {widgetNumber}'
});