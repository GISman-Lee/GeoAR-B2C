define({
  _widgetLabel: 'Kontrolnik pripomočka',
  behavior: 'Vedenje',
  openWidget: 'Koliko pripomočkov je lahko odprtih',
  displayType: 'Prikaži tip',
  sideBySide: 'Drug ob drugem',
  iconStyle: 'Ikona',
  showIconLabel: 'Napis',
  iconSizeOverride: 'Velikost',
  iconInterval: 'Presledek',
  textFormatOverride: 'Besedilo',
  iconBackgroundOverride: 'Ikona',
  openStart: 'Odpri pripomočke, ko je stran naložena',
  widgetsSelected: '{widgetNumber} pripomočkov izbranih'
});