define({
  _widgetLabel: 'Widget-Controller',
  behavior: 'Verhalten',
  openWidget: 'Wie viele Widgets geöffnet werden können',
  displayType: 'Anzeigetyp',
  sideBySide: 'Nebeneinander',
  iconStyle: 'Symbol',
  showIconLabel: 'Beschriftung',
  iconSizeOverride: 'Größe',
  iconInterval: 'Abstand',
  textFormatOverride: 'Text',
  iconBackgroundOverride: 'Symbol',
  openStart: 'Widgets öffnen, wenn die Seite geladen wird',
  widgetsSelected: '{widgetNumber} Widgets ausgewählt'
});