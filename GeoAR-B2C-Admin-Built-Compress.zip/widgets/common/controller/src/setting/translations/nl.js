define({
  _widgetLabel: 'Widget Controller',
  behavior: 'Gedrag',
  openWidget: 'Hoeveel widgets kunnen worden geopend',
  displayType: 'Weergavetype',
  sideBySide: 'Zij aan zij',
  iconStyle: 'Pictogram',
  showIconLabel: 'Label',
  iconSizeOverride: 'Grootte',
  iconInterval: 'Afstand',
  textFormatOverride: 'Tekst',
  iconBackgroundOverride: 'Pictogram',
  openStart: 'Open widgets wanneer de pagina is geladen',
  widgetsSelected: '{widgetNumber} widgets geselecteerd'
});