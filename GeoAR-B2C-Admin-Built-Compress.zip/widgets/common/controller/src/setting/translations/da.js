define({
  _widgetLabel: 'Widget-controller',
  behavior: 'Adfærd',
  openWidget: 'Hvor mange widgets kan åbnes?',
  displayType: 'Vis type',
  sideBySide: 'Side om side',
  iconStyle: 'Ikon',
  showIconLabel: 'Mærke',
  iconSizeOverride: 'Størrelse',
  iconInterval: 'Afstand',
  textFormatOverride: 'Tekst',
  iconBackgroundOverride: 'Ikon',
  openStart: 'Åbner widgets, når siden indlæses',
  widgetsSelected: '{widgetNumber} widgets valgt'
});