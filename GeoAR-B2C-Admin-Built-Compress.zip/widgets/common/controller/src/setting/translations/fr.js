define({
  _widgetLabel: 'Contrôleur de widget',
  behavior: 'Comportement',
  openWidget: 'Nombre de widgets pouvant être ouverts',
  displayType: 'Type d’affichage',
  sideBySide: 'Côte à côte',
  iconStyle: 'Icône',
  showIconLabel: 'Étiquette',
  iconSizeOverride: 'Taille',
  iconInterval: 'Espacement',
  textFormatOverride: 'Texte',
  iconBackgroundOverride: 'Icône',
  openStart: 'Ouvrir les widgets lorsque la page est chargée',
  widgetsSelected: '{widgetNumber} widgets sélectionnés'
});