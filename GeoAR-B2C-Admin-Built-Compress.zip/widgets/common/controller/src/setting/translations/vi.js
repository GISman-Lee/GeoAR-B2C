define({
  _widgetLabel: 'Trình điều khiển Tiện ích',
  behavior: 'Hành vi',
  openWidget: 'Có bao nhiêu tiện ích có thể mở',
  displayType: 'Loại hiển thị',
  sideBySide: 'Song song',
  iconStyle: 'Biểu tượng',
  showIconLabel: 'Nhãn',
  iconSizeOverride: 'Kích thước',
  iconInterval: 'Dấu cách',
  textFormatOverride: 'Văn bản',
  iconBackgroundOverride: 'Biểu tượng',
  openStart: 'Mở tiện ích khi trang được tải ra',
  widgetsSelected: '{widgetNumber} tiện ích được chọn'
});