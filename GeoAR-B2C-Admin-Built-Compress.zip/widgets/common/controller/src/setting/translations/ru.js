define({
  _widgetLabel: 'Контроллер виджетов',
  behavior: 'Поведение',
  openWidget: 'Сколько виджетов можно открыть',
  displayType: 'Тип отображения',
  sideBySide: 'Рядом',
  iconStyle: 'Значок',
  showIconLabel: 'Подпись',
  iconSizeOverride: 'Размер',
  iconInterval: 'Интервал',
  textFormatOverride: 'Текст',
  iconBackgroundOverride: 'Значок',
  openStart: 'Открывать виджеты при загрузке страницы',
  widgetsSelected: '{widgetNumber} виджетов выбрано'
});