define({
  _widgetLabel: 'Widgetkontroller',
  behavior: 'Beteendefunktion',
  openWidget: 'Hur många widgetar går att öppna',
  displayType: 'Visningstyp',
  sideBySide: 'Sida vid sida',
  iconStyle: 'Ikon',
  showIconLabel: 'Etikett',
  iconSizeOverride: 'Storlek',
  iconInterval: 'Avstånd',
  textFormatOverride: 'Text',
  iconBackgroundOverride: 'Ikon',
  openStart: 'Öppna widgetar när sidan har lästs in',
  widgetsSelected: '{widgetNumber} widgetar valda'
});