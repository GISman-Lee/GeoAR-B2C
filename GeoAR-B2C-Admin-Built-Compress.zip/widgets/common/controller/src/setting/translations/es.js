define({
  _widgetLabel: 'Controlador de widget',
  behavior: 'Comportamiento',
  openWidget: 'Cuántos widgets se pueden abrir',
  displayType: 'Tipo de visualización',
  sideBySide: 'En paralelo',
  iconStyle: 'Icono',
  showIconLabel: 'Etiqueta',
  iconSizeOverride: 'Tamaño',
  iconInterval: 'Espaciado',
  textFormatOverride: 'Texto',
  iconBackgroundOverride: 'Icono',
  openStart: 'Abrir widgets al cargar la página',
  widgetsSelected: '{widgetNumber} widgets seleccionados'
});