define({
  _widgetLabel: 'Controlador de Widgets',
  behavior: 'Comportamento',
  openWidget: 'Quantos widgets é possível abrir',
  displayType: 'Exibir tipo',
  sideBySide: 'Lado a lado',
  iconStyle: 'Ícone',
  showIconLabel: 'Etiqueta',
  iconSizeOverride: 'Tamanho',
  iconInterval: 'Espaçamento',
  textFormatOverride: 'Texto',
  iconBackgroundOverride: 'Ícone',
  openStart: 'Abrir widgets quando a página é carregada',
  widgetsSelected: '{widgetNumber} widgets selecionados'
});