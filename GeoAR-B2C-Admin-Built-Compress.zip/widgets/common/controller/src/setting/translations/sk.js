define({
  _widgetLabel: 'Ovládač widgetu',
  behavior: 'Správanie',
  openWidget: 'Koľko widgetov môže byť otvorených',
  displayType: 'Typ zobrazenia',
  sideBySide: 'Vedľa seba',
  iconStyle: 'Ikona',
  showIconLabel: 'Označenie',
  iconSizeOverride: 'Veľkosť',
  iconInterval: 'Rozostup',
  textFormatOverride: 'Text',
  iconBackgroundOverride: 'Ikona',
  openStart: 'Otvoriť widgety, keď sa stránka načíta',
  widgetsSelected: 'vybraných {widgetNumber} widgetov'
});