define({
  _widgetLabel: 'Pengontrol Widget',
  behavior: 'Perilaku',
  openWidget: 'Berapa banyak widget yang dapat dibuka',
  displayType: 'Tipe tampilan',
  sideBySide: 'Berdampingan',
  iconStyle: 'Ikon',
  showIconLabel: 'Label',
  iconSizeOverride: 'Ukuran',
  iconInterval: 'Jarak',
  textFormatOverride: 'Teks',
  iconBackgroundOverride: 'Ikon',
  openStart: 'Buka widget saat halaman dimuat',
  widgetsSelected: '{widgetNumber} widget terpilih'
});