define({
  _widgetLabel: 'Εργαλείο ελέγχου του widget',
  behavior: 'Συμπεριφορά',
  openWidget: 'Αριθμός των widget που θα μπορούν να ανοιχτούν',
  displayType: 'Τύπος εμφάνισης',
  sideBySide: 'Σε παράθεση',
  iconStyle: 'Εικονίδιο',
  showIconLabel: 'Ετικέτα',
  iconSizeOverride: 'Μέγεθος',
  iconInterval: 'Απόσταση',
  textFormatOverride: 'Κείμενο',
  iconBackgroundOverride: 'Εικονίδιο',
  openStart: 'Άνοιγμα των widget κατά τη φόρτωση της σελίδας',
  widgetsSelected: '{widgetNumber} επιλεγμένα widget'
});