define({
  _widgetLabel: 'Kontroler widżetów',
  behavior: 'Zachowanie',
  openWidget: 'Ile widżetów można otworzyć',
  displayType: 'Typ wyświetlania',
  sideBySide: 'Obok siebie',
  iconStyle: 'Ikona',
  showIconLabel: 'Etykieta',
  iconSizeOverride: 'Rozmiar',
  iconInterval: 'Odstępy',
  textFormatOverride: 'Tekst',
  iconBackgroundOverride: 'Ikona',
  openStart: 'Otwieraj widżety po wczytaniu strony',
  widgetsSelected: 'Wybrano następującą liczbę widżetów: {widgetNumber}'
});