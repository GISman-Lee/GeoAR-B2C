define({
  _widgetLabel: 'Controler widget',
  behavior: 'Comportament',
  openWidget: 'Câte widgeturi pot fi deschise',
  displayType: 'Tip afișare',
  sideBySide: 'Alăturat',
  iconStyle: 'Pictogramă',
  showIconLabel: 'Etichetă',
  iconSizeOverride: 'Dimensiune',
  iconInterval: 'Spațiere',
  textFormatOverride: 'Text',
  iconBackgroundOverride: 'Pictogramă',
  openStart: 'Deschideți widgeturi atunci când pagina este încărcată',
  widgetsSelected: '{widgetNumber} widgeturi selectate'
});