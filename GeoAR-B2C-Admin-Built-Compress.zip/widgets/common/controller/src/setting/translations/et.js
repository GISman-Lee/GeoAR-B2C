define({
  _widgetLabel: 'Vidina kontroller',
  behavior: 'Eeskiri',
  openWidget: 'Kui mitu vidinat saab avada',
  displayType: 'Kuva tüüp',
  sideBySide: 'Kõrvuti',
  iconStyle: 'Ikoon',
  showIconLabel: 'Märgis',
  iconSizeOverride: 'Suurus',
  iconInterval: 'Hõrendus',
  textFormatOverride: 'Tekst',
  iconBackgroundOverride: 'Ikoon',
  openStart: 'Avage vidinad, kui lehekülg on laetud',
  widgetsSelected: 'Valitud on {widgetNumber} vidinat'
});