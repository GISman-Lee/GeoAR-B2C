define({
  _widgetLabel: 'Controlador de widget',
  behavior: 'Comportament',
  openWidget: 'Quants widgets es poden obrir',
  displayType: 'Tipus de visualització',
  sideBySide: 'Paral·lel',
  iconStyle: 'Icona',
  showIconLabel: 'Etiqueta',
  iconSizeOverride: 'Mida',
  iconInterval: 'Espaiat',
  textFormatOverride: 'Text',
  iconBackgroundOverride: 'Icona',
  openStart: 'Obre els widgets quan es carregui la pàgina',
  widgetsSelected: '{widgetNumber} widgets seleccionats'
});