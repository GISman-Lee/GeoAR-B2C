define({
  _widgetLabel: 'Widget Controller',
  behavior: 'Chování',
  openWidget: 'Kolik widgetů lze otevřít',
  displayType: 'Typ zobrazení',
  sideBySide: 'Vedle sebe',
  iconStyle: 'Ikona',
  showIconLabel: 'Štítek',
  iconSizeOverride: 'Velikost',
  iconInterval: 'Rozestup',
  textFormatOverride: 'Text',
  iconBackgroundOverride: 'Ikona',
  openStart: 'Po načtení stránky otevřít widgety',
  widgetsSelected: '{widgetNumber} widgetů vybráno'
});