define({
  _widgetLabel: '微件控制器',
  behavior: '行为',
  openWidget: '可以打开多少个微件',
  displayType: '显示类型',
  sideBySide: '并排',
  iconStyle: '图标',
  showIconLabel: '标注',
  iconSizeOverride: '大小',
  iconInterval: '间距',
  textFormatOverride: '文本型',
  iconBackgroundOverride: '图标',
  openStart: '页面加载时打开微件',
  widgetsSelected: '已选择 {widgetNumber} 个微件'
});