define({
  _widgetLabel: 'Logrīka kontrolleris',
  behavior: 'Darbība',
  openWidget: 'Cik daudz logrīku var atvērt',
  displayType: 'Parādīšanas veids',
  sideBySide: 'Blakus',
  iconStyle: 'Ikona',
  showIconLabel: 'Kartes teksts',
  iconSizeOverride: 'Izmērs',
  iconInterval: 'Atstarpes',
  textFormatOverride: 'Teksts',
  iconBackgroundOverride: 'Ikona',
  openStart: 'Atvērt logrīkus pēc lapas ielādēšanas',
  widgetsSelected: 'Atlasīti {widgetNumber} logrīki'
});