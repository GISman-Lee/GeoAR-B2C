define({
  _widgetLabel: 'Kontroler vidžeta',
  behavior: 'Ponašanje',
  openWidget: 'Koliko vidžeta može da se otvori',
  displayType: 'Tip prikaza',
  sideBySide: 'Uporedno',
  iconStyle: 'Ikona',
  showIconLabel: 'Oznaka',
  iconSizeOverride: 'Veličina',
  iconInterval: 'Razmak',
  textFormatOverride: 'Tekst',
  iconBackgroundOverride: 'Ikona',
  openStart: 'Otvori vidžete kada se stranica učita',
  widgetsSelected: '{widgetNumber} izabranih vidžeta'
});