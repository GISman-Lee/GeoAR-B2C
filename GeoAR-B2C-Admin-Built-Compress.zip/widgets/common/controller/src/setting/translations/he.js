define({
  _widgetLabel: 'פקד ווידג\'ט',
  behavior: 'התנהגות',
  openWidget: 'כמה ווידג\'טים ניתן לפתוח',
  displayType: 'הצג סוג',
  sideBySide: 'זה לצד זה',
  iconStyle: 'סמל',
  showIconLabel: 'תווית',
  iconSizeOverride: 'גודל',
  iconInterval: 'רווחים',
  textFormatOverride: 'טקסט',
  iconBackgroundOverride: 'סמל',
  openStart: 'פתח ווידג\'טים בעת טעינת הדף',
  widgetsSelected: '{widgetNumber} ווידג\'טים נבחרו'
});