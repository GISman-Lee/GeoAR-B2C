define({
  _widgetLabel: 'ตัวควบคุมวิดเจ็ต',
  behavior: 'ลักษณะ',
  openWidget: 'สามารถเปิดวิดเจ็ตได้กี่รายการ',
  displayType: 'ประเภทการแสดง',
  sideBySide: 'ติดกัน',
  iconStyle: 'ไอค่อน',
  showIconLabel: 'ป้ายชื่อ',
  iconSizeOverride: 'ขนาด',
  iconInterval: 'การเว้นวรรค',
  textFormatOverride: 'ข้อความ',
  iconBackgroundOverride: 'ไอค่อน',
  openStart: 'เปิดวิดเจ็ตเมื่อโหลดหน้าเสร็จ',
  widgetsSelected: '{widgetNumber} วิดเจ็ตที่เลือก'
});