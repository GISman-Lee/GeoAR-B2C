define({
  _widgetLabel: '微件控制器',
  placeholder: '将微件拖到此处',
  addWidget: '添加微件',
  moveOrRemoveWidget: '移动微件'
});