define({
  _widgetLabel: 'Pienoisohjelman säädin',
  placeholder: 'Vedä pienoisohjelma tähän',
  addWidget: 'Lisää pienoisohjelma',
  moveOrRemoveWidget: 'Siirrä pienoisohjelmaa'
});