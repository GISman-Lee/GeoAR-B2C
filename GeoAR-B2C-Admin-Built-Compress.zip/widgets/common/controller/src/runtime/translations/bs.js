define({
  _widgetLabel: 'Kontoler widgeta',
  placeholder: 'Povucite widget ovdje',
  addWidget: 'Dodaj widget',
  moveOrRemoveWidget: 'Pomakni widget'
});