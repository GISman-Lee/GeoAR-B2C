define({
  _widgetLabel: 'פקד ווידג\'ט',
  placeholder: 'גרור ווידג\'ט לכאן',
  addWidget: 'הוסף ווידג\'ט',
  moveOrRemoveWidget: 'הזז וידג\'ט'
});