define({
  _widgetLabel: 'Vidina kontroller',
  placeholder: 'Lohista vidin siia',
  addWidget: 'Lisa vidin',
  moveOrRemoveWidget: 'Teisalda vidin'
});