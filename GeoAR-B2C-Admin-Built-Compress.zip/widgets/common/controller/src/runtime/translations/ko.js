define({
  _widgetLabel: '위젯 컨트롤러',
  placeholder: '위젯을 여기로 드래그',
  addWidget: '위젯 추가',
  moveOrRemoveWidget: '위젯 이동'
});