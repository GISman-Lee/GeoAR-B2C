define({
  _widgetLabel: 'Widget Controller',
  placeholder: 'Přetáhnout widget sem',
  addWidget: 'Přidat widget',
  moveOrRemoveWidget: 'Přesunout widget'
});