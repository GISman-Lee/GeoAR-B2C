define({
  _widgetLabel: 'Widget Controller',
  placeholder: 'Widget hierheen slepen',
  addWidget: 'Widget toevoegen',
  moveOrRemoveWidget: 'Widget verplaatsen'
});