define({
  _widgetLabel: 'Pengontrol Widget',
  placeholder: 'Tarik widget ke sini',
  addWidget: 'Tambahkan widget',
  moveOrRemoveWidget: 'Gerakkan widget'
});