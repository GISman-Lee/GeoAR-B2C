define({
  _widgetLabel: 'Widgetvezérlő',
  placeholder: 'Húzza ide a widgetet',
  addWidget: 'Widget hozzáadása',
  moveOrRemoveWidget: 'Widget áthelyezése'
});