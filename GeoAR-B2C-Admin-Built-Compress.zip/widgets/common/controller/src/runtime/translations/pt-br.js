define({
  _widgetLabel: 'Controlador de Widget',
  placeholder: 'Arraste o widget aqui',
  addWidget: 'Adicionar widget',
  moveOrRemoveWidget: 'Mover widget'
});