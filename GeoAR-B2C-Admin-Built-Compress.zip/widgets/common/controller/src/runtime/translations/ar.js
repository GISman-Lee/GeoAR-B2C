define({
  _widgetLabel: 'أداة التحكم في عنصر واجهة المستخدم',
  placeholder: 'سحب عنصر واجهة المستخدم هنا',
  addWidget: 'إضافة عنصر واجهة الاستخدام',
  moveOrRemoveWidget: 'نقل عنصر واجهة المستخدم'
});