define({
  _widgetLabel: 'Контроллер виджетов',
  placeholder: 'Перетащите виджет сюда',
  addWidget: 'Добавить виджет',
  moveOrRemoveWidget: 'Переместить виджет'
});