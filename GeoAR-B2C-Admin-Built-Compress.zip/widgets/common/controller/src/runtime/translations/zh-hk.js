define({
  _widgetLabel: 'Widget 控制器',
  placeholder: '將 widget 拖曳到這裡',
  addWidget: '新增 widget',
  moveOrRemoveWidget: '移動 widget'
});