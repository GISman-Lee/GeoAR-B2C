define({
  _widgetLabel: 'Kontrolnik pripomočka',
  placeholder: 'Povleci pripomoček sem',
  addWidget: 'Dodaj pripomoček',
  moveOrRemoveWidget: 'Premakni pripomoček'
});