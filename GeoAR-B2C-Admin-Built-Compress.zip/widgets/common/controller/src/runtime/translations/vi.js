define({
  _widgetLabel: 'Trình điều khiển Tiện ích',
  placeholder: 'Kéo tiện ích vào đây',
  addWidget: 'Thêm tiện ích',
  moveOrRemoveWidget: 'Di chuyển tiện ích'
});