export default {
  _widgetLabel: 'Widget Controller',
  placeholder: 'Drag widget here',
  addWidget: 'Add widget',
  moveOrRemoveWidget: 'Move widget'
}
