define({
  _widgetLabel: 'Miniprogramkontroller',
  placeholder: 'Tegn miniprogram her',
  addWidget: 'Legg til miniprogram',
  moveOrRemoveWidget: 'Flytt miniprogram'
});