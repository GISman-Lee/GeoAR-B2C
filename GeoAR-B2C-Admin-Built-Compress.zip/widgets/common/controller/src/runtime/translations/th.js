define({
  _widgetLabel: 'ตัวควบคุมวิดเจ็ต',
  placeholder: 'ลากวิดเจ็ตมาที่นี่',
  addWidget: 'เพิ่มวิดเจ็ต',
  moveOrRemoveWidget: 'ย้ายวิดเจ็ต'
});