define({
  _widgetLabel: 'Contrôleur de widget',
  placeholder: 'Faire glisser le widget ici',
  addWidget: 'Ajouter un widget',
  moveOrRemoveWidget: 'Déplacer le widget'
});