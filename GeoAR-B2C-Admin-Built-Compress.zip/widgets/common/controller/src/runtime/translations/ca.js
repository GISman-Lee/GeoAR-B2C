define({
  _widgetLabel: 'Controlador de widget',
  placeholder: 'Arrossegueu el widget aquí',
  addWidget: 'Afegeix un widget',
  moveOrRemoveWidget: 'Mou el widget'
});