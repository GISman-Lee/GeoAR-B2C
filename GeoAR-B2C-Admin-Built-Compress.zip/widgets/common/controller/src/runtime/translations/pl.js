define({
  _widgetLabel: 'Kontroler widżetów',
  placeholder: 'Przeciągnij widżet tutaj',
  addWidget: 'Dodaj widżet',
  moveOrRemoveWidget: 'Przenieś widżet'
});