define({
  _widgetLabel: 'Widget-Controller',
  placeholder: 'Widget hier her ziehen',
  addWidget: 'Widget hinzufügen',
  moveOrRemoveWidget: 'Widget verschieben'
});