define({
  _widgetLabel: 'Controler widget',
  placeholder: 'Trageți widgetul aici',
  addWidget: 'Adăugați un widget',
  moveOrRemoveWidget: 'Mutați widget-ul'
});