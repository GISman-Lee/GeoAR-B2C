define({
  _widgetLabel: 'Logrīka kontrolleris',
  placeholder: 'Velciet logrīku šeit',
  addWidget: 'Pievienot logrīku',
  moveOrRemoveWidget: 'Pārvietot logrīku'
});