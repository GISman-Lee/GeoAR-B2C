define({
  _widgetLabel: 'Контролер віджетів',
  placeholder: 'Перетягніть віджет сюди',
  addWidget: 'Додати віджет',
  moveOrRemoveWidget: 'Перемістити віджет'
});