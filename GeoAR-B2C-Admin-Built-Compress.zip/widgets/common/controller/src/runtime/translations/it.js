define({
  _widgetLabel: 'Controllore del widget',
  placeholder: 'Trascinare il widget qui',
  addWidget: 'Aggiungi widget',
  moveOrRemoveWidget: 'Spostare widget'
});