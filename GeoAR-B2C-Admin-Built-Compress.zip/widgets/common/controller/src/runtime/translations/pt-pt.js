define({
  _widgetLabel: 'Controlador de Widgets',
  placeholder: 'Arrastar widget para aqui',
  addWidget: 'Adicionar Widget',
  moveOrRemoveWidget: 'Mover widget'
});