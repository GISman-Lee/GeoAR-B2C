define({
  _widgetLabel: 'Valdiklis',
  placeholder: 'Vilkite valdiklį čia',
  addWidget: 'Įtraukti valdiklį',
  moveOrRemoveWidget: 'Perkelti valdiklį'
});