define({
  _widgetLabel: 'Εργαλείο ελέγχου του widget',
  placeholder: 'Σύρετε το widget και αποθέστε το εδώ.',
  addWidget: 'Προσθήκη του widget',
  moveOrRemoveWidget: 'Μετακίνηση του widget'
});