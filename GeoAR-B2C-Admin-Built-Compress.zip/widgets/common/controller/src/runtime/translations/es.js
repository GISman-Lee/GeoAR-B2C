define({
  _widgetLabel: 'Controlador de widget',
  placeholder: 'Arrastrar widget aquí',
  addWidget: 'Agregar widget',
  moveOrRemoveWidget: 'Mover widget'
});