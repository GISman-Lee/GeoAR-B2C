define({
  _widgetLabel: 'Widget-controller',
  placeholder: 'Træk widget hertil',
  addWidget: 'Tilføj widget',
  moveOrRemoveWidget: 'Flyt widget'
});