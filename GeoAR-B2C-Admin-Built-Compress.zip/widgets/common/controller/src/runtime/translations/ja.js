define({
  _widgetLabel: 'ウィジェット コントローラー',
  placeholder: 'ここにウィジェットをドラッグ',
  addWidget: 'ウィジェットの追加',
  moveOrRemoveWidget: 'ウィジェットの移動'
});