define({
  _widgetLabel: 'Ovládač widgetu',
  placeholder: 'Potiahnuť widget sem',
  addWidget: 'Pridať widget',
  moveOrRemoveWidget: 'Presunúť widget'
});