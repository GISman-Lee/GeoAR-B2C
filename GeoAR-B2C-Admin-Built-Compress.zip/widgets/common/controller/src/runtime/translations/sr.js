define({
  _widgetLabel: 'Kontroler vidžeta',
  placeholder: 'Prevuci vidžet ovde',
  addWidget: 'Dodaj vidžet',
  moveOrRemoveWidget: 'Pomeri vidžet'
});