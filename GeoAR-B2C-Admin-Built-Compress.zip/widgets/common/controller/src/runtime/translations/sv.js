define({
  _widgetLabel: 'Widgetkontroller',
  placeholder: 'Dra widgeten hit',
  addWidget: 'Lägg till widget',
  moveOrRemoveWidget: 'Flytta widget'
});