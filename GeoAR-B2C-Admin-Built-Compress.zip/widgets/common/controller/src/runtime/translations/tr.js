define({
  _widgetLabel: 'Widget Controller (Araç Denetleyicisi)',
  placeholder: 'Aracı buraya sürükleyin',
  addWidget: 'Araç ekle',
  moveOrRemoveWidget: 'Aracı taşı'
});