define({
  _widgetLabel: 'Tekst',
  placeholder: 'Dubbelklikken om tekst te bewerken'
});