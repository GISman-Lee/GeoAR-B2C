define({
  _widgetLabel: 'Tekstas',
  placeholder: 'Dukart spustelėkite, norėdami redaguoti tekstą'
});