define({
  _widgetLabel: '텍스트',
  placeholder: '텍스트를 편집하려면 더블 클릭'
});