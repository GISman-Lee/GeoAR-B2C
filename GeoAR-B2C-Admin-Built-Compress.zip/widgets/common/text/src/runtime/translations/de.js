define({
  _widgetLabel: 'Text',
  placeholder: 'Doppelklicken, um Text zu bearbeiten'
});