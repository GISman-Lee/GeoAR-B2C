define({
  _widgetLabel: 'Teksts',
  placeholder: 'Veiciet dubultklikšķi, lai rediģētu tekstu'
});