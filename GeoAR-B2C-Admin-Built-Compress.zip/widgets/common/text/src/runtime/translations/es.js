define({
  _widgetLabel: 'Texto',
  placeholder: 'Haga doble clic para editar el texto'
});