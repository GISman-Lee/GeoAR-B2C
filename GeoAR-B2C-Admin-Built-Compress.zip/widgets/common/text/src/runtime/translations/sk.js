define({
  _widgetLabel: 'Text',
  placeholder: 'Dvojklik pre úpravu textu'
});