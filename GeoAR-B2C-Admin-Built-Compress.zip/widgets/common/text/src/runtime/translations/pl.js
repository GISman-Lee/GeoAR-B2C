define({
  _widgetLabel: 'Tekst',
  placeholder: 'Kliknij dwukrotnie, aby edytować tekst'
});