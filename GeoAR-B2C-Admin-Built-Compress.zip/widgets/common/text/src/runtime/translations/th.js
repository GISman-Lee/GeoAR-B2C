define({
  _widgetLabel: 'ตัวอักษร',
  placeholder: 'ดับเบิลคลิกเพื่อแก้ไขข้อความ'
});