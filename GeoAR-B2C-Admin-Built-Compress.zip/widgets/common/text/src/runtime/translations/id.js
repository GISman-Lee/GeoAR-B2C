define({
  _widgetLabel: 'Teks',
  placeholder: 'Klik dua kali untuk mengedit teks'
});