define({
  _widgetLabel: 'Văn bản',
  placeholder: 'Nhấp đúp chuột để chỉnh sửa văn bản'
});