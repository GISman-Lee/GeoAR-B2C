define({
  _widgetLabel: 'Tekst',
  placeholder: 'Dobbeltklik for at redigere tekst'
});