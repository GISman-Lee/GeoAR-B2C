define({
  _widgetLabel: 'Testo',
  placeholder: 'Fare doppio clic per modificare il testo'
});