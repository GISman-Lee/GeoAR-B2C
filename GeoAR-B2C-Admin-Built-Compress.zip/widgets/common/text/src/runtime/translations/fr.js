define({
  _widgetLabel: 'Texte',
  placeholder: 'Double-cliquer pour modifier le texte'
});