define({
  _widgetLabel: 'Text',
  placeholder: 'Dubbelklicka för att redigera text'
});