define({
  _widgetLabel: 'Текст',
  placeholder: 'Двічі клацніть, щоб редагувати текст'
});