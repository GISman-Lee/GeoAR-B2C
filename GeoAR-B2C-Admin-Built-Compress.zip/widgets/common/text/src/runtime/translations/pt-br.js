define({
  _widgetLabel: 'Texto',
  placeholder: 'Clique duas vezes para editar o texto'
});