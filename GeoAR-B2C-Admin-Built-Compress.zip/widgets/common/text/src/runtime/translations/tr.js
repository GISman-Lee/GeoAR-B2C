define({
  _widgetLabel: 'Metin',
  placeholder: 'Metni düzenlemek için çift tıklayın'
});