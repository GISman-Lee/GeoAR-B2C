define({
  _widgetLabel: 'النص',
  placeholder: 'انقر نقرًا مزدوجًا لتحرير النص'
});