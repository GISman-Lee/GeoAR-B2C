define({
  _widgetLabel: 'Κείμενο',
  placeholder: 'Κάντε διπλό κλικ για να επεξεργαστείτε το κείμενο.'
});