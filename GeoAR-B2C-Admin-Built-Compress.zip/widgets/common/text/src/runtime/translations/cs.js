define({
  _widgetLabel: 'Text',
  placeholder: 'Dvojitým kliknutím zahájíte editaci textu'
});