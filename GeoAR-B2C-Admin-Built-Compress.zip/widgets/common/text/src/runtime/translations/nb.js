define({
  _widgetLabel: 'Tekst',
  placeholder: 'Dobbeltklikk for å redigere tekst'
});