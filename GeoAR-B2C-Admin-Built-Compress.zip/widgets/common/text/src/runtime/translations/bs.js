define({
  _widgetLabel: 'Tekst',
  placeholder: 'Dvaput kliknite da biste uredili tekst'
});