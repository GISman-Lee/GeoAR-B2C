define({
  _widgetLabel: '文字',
  placeholder: '按兩下以編輯文字'
});