define({
  _widgetLabel: '文本',
  placeholder: '双击以编辑文本'
});