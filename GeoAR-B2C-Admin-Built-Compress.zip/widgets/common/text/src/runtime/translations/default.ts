export default {
  _widgetLabel: 'Text',
  placeholder: 'Double click to edit text'
}