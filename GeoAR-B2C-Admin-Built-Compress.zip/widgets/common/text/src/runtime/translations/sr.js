define({
  _widgetLabel: 'Tekst',
  placeholder: 'Dvaput kliknite da biste izmenili tekst'
});