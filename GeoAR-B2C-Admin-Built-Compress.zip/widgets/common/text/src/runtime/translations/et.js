define({
  _widgetLabel: 'Tekst',
  placeholder: 'Teksti muutmiseks tehke palun topeltklõps'
});