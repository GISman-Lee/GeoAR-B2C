define({
  _widgetLabel: 'Текст',
  placeholder: 'Дважды щелкните для редактирования текста'
});