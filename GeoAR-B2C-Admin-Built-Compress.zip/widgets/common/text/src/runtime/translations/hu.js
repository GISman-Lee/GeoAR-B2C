define({
  _widgetLabel: 'Szöveg',
  placeholder: 'Kattintson duplán a szöveg szerkesztéséhez'
});