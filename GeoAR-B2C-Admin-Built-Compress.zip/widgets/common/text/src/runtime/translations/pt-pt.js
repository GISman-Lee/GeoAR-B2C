define({
  _widgetLabel: 'Texto',
  placeholder: 'Clicar duas vezes para editar texto'
});