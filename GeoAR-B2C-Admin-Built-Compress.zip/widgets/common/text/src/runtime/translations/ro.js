define({
  _widgetLabel: 'Text',
  placeholder: 'Faceți dublu clic pentru a edita textul'
});