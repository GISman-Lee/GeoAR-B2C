define({
  _widgetLabel: 'テキスト',
  placeholder: 'ダブルクリックしてテキストを編集'
});