define({
  _widgetLabel: 'Text',
  placeholder: 'Feu doble clic per editar el text'
});