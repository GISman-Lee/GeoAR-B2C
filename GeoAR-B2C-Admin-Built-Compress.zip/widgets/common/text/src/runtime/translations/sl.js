define({
  _widgetLabel: 'Besedilo',
  placeholder: 'Dvokliknite za urejanje besedila'
});