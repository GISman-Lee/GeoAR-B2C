define({
  _widgetLabel: 'Teksti',
  placeholder: 'Muokkaa tekstiä kaksoisnapsauttamalla'
});