define({
  _widgetLabel: 'טקסט',
  placeholder: 'לחץ פעמיים לעריכת הטקסט'
});